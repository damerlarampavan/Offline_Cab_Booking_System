package com.example.rider_app;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.Settings;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class details extends MainActivity {
    private static final int REQUEST_LOCATION=1;

    private Button send;

    private String showlocationTxt;
    private EditText editTxtname;

    //public static String newmsg;

    LocationManager locationManager;
    String Latitude,Longitude;
    public static final String SMS_RECEIVED = "android.provider.Telephony.SMS_RECEIVED";

    private static final int MY_PERMISSIONS_REQUEST_RECEIVE_SMS=0;
    //TextView messageField;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);




        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS) != PackageManager.PERMISSION_GRANTED){
            if(ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.RECEIVE_SMS)){

            } else{
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECEIVE_SMS}, MY_PERMISSIONS_REQUEST_RECEIVE_SMS);

            }
        }

        editTxtname = findViewById(R.id.editText);

        //ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS, Manifest.permission.READ_SMS}, PackageManager.PERMISSION_GRANTED);

        send = findViewById(R.id.button3);
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendSMS(v);
            }
        });


    }
    private void getLocation() {
        if(ActivityCompat.checkSelfPermission(details.this,Manifest.permission.ACCESS_FINE_LOCATION)!= PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(details.this,
                Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},REQUEST_LOCATION);
        }
        else{
            Location LocationGps = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            Location LocationNetwork = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            Location LocationPassive = locationManager.getLastKnownLocation(LocationManager.PASSIVE_PROVIDER);

            if(LocationGps!=null){
                double lat= LocationGps.getLatitude();
                double longi = LocationGps.getLongitude();

                Latitude= String.valueOf(lat);
                Longitude = String.valueOf(longi);

                showlocationTxt = Longitude+" "+Latitude;
            }
            else if(LocationNetwork!=null){
                double lat= LocationNetwork.getLatitude();
                double longi = LocationNetwork.getLongitude();

                Latitude= String.valueOf(lat);
                Longitude = String.valueOf(longi);

                showlocationTxt = Longitude+" "+Latitude;
            }
            else if(LocationPassive!=null){
                double lat= LocationPassive.getLatitude();
                double longi =LocationPassive.getLongitude();

                Latitude= String.valueOf(lat);
                Longitude = String.valueOf(longi);

                showlocationTxt = Longitude+" "+Latitude;
            }else{
                Toast.makeText(this,"can't get your location",Toast.LENGTH_SHORT).show();
            }
        }
    }
    private void onGPS(){
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Enable GPS").setCancelable(false).setPositiveButton("YES", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
            }
        }).setNegativeButton("NO", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        final AlertDialog alterDialog=builder.create();
        alterDialog.show();
    }
    public void sendSMS(View view){
        System.out.println("CheckPoint--1-------------");
        String name = editTxtname.getText().toString();
        System.out.println("CheckPoint--2-------------");
        locationManager=(LocationManager) getSystemService(Context.LOCATION_SERVICE);

        if(!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)){
            onGPS();
        }else{
            getLocation();
        }
        String gps = showlocationTxt;

        if(!(name.equals("") )){

        SmsManager mySmsManager = SmsManager.getDefault();

        mySmsManager.sendTextMessage(MainActivity.number1,null, "Booking "+name+" "+gps, null, null);
        Driver_detail();

        Toast.makeText(this, "Please Wait while the nearest driver is being assigned" , Toast.LENGTH_LONG).show();
        }else{

            Toast.makeText(this, "Please enter a valid Name" , Toast.LENGTH_LONG).show();

        }
    }
    private void Driver_detail(){
        Intent intent = new Intent(this, Driver_details.class);
        startActivity(intent);
    }
}
